<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Midnight Pastelería</title>

    <link href="//fonts.googleapis.com/css2?family=Dosis:wght@300;400;500;600;800&display=swap" rel="stylesheet">

    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
  </head>
  <body>
<!--header-->
<header id="site-header" class="fixed-top">
  <div class="container">
      <nav class="navbar navbar-expand-lg stroke px-0">
          <h1> <a class="navbar-brand" href="index.php">
              <img src="assets/images/logo1.png" alt="burger logo"width="55px" /> Midnight Pastelería


              </a></h1>
          <!-- if logo is image enable this   
  <a class="navbar-brand" href="#index.php">
      <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
  </a> -->
          <button class="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse"
              data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"
              aria-label="Toggle navigation">
              <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
              <span class="navbar-toggler-icon fa icon-close fa-times"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul class="navbar-nav ml-auto">
                  <li class="nav-item @@home__active">
                      <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item active">
                      <a class="nav-link" href="about.php">About</a>
                  </li>
                  <li class="nav-item @@menu__active">
                      <a class="nav-link" href="menu.php">Menu</a>
                  </li>
                  <li class="nav-item @@contact__active">
                      <a class="nav-link" href="contact.php">Contact</a>
                  </li>
                  <!--/search-right-->
                  <div class="search-right">
                      <a href="#search" title="search"><span class="fa fa-search" aria-hidden="true"></span></a>
                      <!-- search popup -->
                      <div id="search" class="pop-overlay">
                          <div class="popup">
                              <h4 class="mb-3">Search here</h4>
                              <form action="error.php" method="GET" class="search-box">
                                  <input type="search" placeholder="Enter Keyword" name="search" required="required"
                                      autofocus="">
                                  <button type="submit" class="btn btn-style btn-primary">Search</button>
                              </form>

                          </div>
                          <a class="close" href="#close">×</a>
                      </div>
                      <!-- /search popup -->
                  </div>
                  <!--//search-right-->
              </ul>
          </div>
          <!-- toggle switch for light and dark theme -->
          <div class="mobile-position">
              <nav class="navigation">
                  <div class="theme-switch-wrapper">
                      <label class="theme-switch" for="checkbox">
                          <input type="checkbox" id="checkbox">
                          <div class="mode-container">
                              <i class="gg-sun"></i>
                              <i class="gg-moon"></i>
                          </div>
                      </label>
                  </div>
              </nav>
          </div>
          <!-- //toggle switch for light and dark theme -->
      </nav>
  </div>
</header>
<!--/header-->
<section class="w3l-about-breadcrumb">
    <div class="breadcrumb-bg breadcrumb-bg-about py-5">
        <div class="container py-lg-5 py-md-3">
            <h2 class="title">About Us</h2>
        </div>
    </div>
</section>
<section class="w3l-aboutblock1" id="about">
    <div class="midd-w3 py-5">
        <div class="container py-lg-5 py-md-4 py-2">
            <div class="row">
                <div class="col-lg-6 left-wthree-img text-righ">
                    <div class="position-relative">
                        <img src="assets/images/ab1.jpg" alt="" class="img-fluid radius-image-full" style= 'margin-top: 45'px;' width= 1000px>
                    </div>
                </div>
                <div class="col-lg-6 mt-lg-0 mt-md-5 mt-4 about-right-faq align-self">
                    <h5 class="title-small mb-1">Our Pastry</h5>
                    <h3 class="title-big">Hello and Welcome to our Pastelería! Every Bite Taste Like Heaven</h3>
                    <p class="mt-4">The extensive variety of baked items available at Pastelería is well known. A variety of pastries, cakes, tarts, pies, bread, and other baked goods, both sweet and savory, are available for customers to delight in. The dishes frequently combine regional and foreign flavors, highlighting the pastry chefs' skill. High-quality ingredients are used as a priority in pastry businesses. It's common practice to use freshly milled flour, quality butter, farm-fresh eggs, and the best chocolates and fruits to make delectable pastries that tempt the palate. It is going to salivate over these goodies, whether it's the s'mores fondue, banana split waffles, or chocolate hazelnut milkshakes.</p>
                    <a class="btn btn-primary btn-style mt-md-5 mt-4 mr-4" href="about.php"> Read More </a>

                    <!-- <a href="#small-dialog1" class="popup-with-zoom-anim play-view text-center position-absolute mt-md-5 mt-4">
                        <span class="video-play-icon">
                            <span class="fa fa-play"></span> 
                        </span>
                        See Our Story
                    </a>
                     dialog itself, mfp-hide class is required to make dialog hidden 
                    <div id="small-dialog1" class="zoom-anim-dialog mfp-hide">
                        <iframe src="https://www.youtube.com/embed/dCVEY88Fn1k" allow="autoplay; fullscreen" allowfullscreen=""></iframe>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
</section>

<!-- features -->
<section class="w3l-reasons py-5" id="how">
    <div class="main-w3 py-lg-5 py-md-4">
        <div class="container">
            <div class="title-content text-center">
                <h6 class="title-small">Our process</h6>
                <h3 class="title-big">How We Work</h3>
            </div>
            <div class="row main-cont-wthree-fea mt-5 pt-lg-4 text-center">
                <div class="col-lg-3 col-sm-6 grids-feature">
                    <a href="#url" class="icon"><span class="fa fa-pie-chart"></span></a>
                    <h4><a href="#feature" class="title-head">Food Served Hot</a></h4>
                    <p>Our pastry shop offers a wide variety of hot and fresh food, including savory pies and quiches, as well as sweet treats like warm croissants and cinnamon rolls</p>
                </div>
                <div class="col-lg-3 col-sm-6 grids-feature mt-sm-0 mt-5">
                    <a href="#url" class="icon"><span class="fa fa-cogs"></span></a>
                    <h4><a href="#feature" class="title-head">Ample options</a></h4>
                    <p>Our pastry shop offers a diverse menu of pastries, including classics like croissants and danishes, and more indulgent options like chocolate eclairs and custard tarts. </p>
                </div>
                <div class="col-lg-3 col-sm-6 grids-feature mt-lg-0 mt-sm-5 mt-5">
                    <a href="#url" class="icon"><span class="fa fa-glass"></span></a>
                    <h4><a href="#feature" class="title-head">In-House Brevery</a></h4>
                    <p>Our pastry shop takes pride in having an in-house bakery where we craft our pastries. our in-house brevery guarantees a truly enjoyable and delightful pastry experience.
</p>
                </div>
                <div class="col-lg-3 col-sm-6 grids-feature mt-lg-0 mt-sm-5 mt-5">
                <a href="#url" class="icon"><span class="fa fa-shopping-basket"></span></a>
                    <h4><a href="#feature" class="title-head">Fast Ordering</a></h4>
                    <p>We prioritize fast and convenient order placement for our pastries, aiming for quick and efficient service. Whether you visit our shop or order online, we prioritize all.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- //features -->

<!--/team-sec-->
<section class="w3l-team-main" id="team">
    <div class="team py-5">
        <div class="container py-lg-5">
            <div class="title-content text-center">
                <h6 class="title-small">Experts and skillful</h6>
                <h3 class="title-big">Our Experienced Chefs</h3>
            </div>
            <div class="row team-row mt-md-5 mt-5">
                <div class="col-lg-3 col-6 team-wrap">
                    <div class="team-member text-center">
                        <div class="team-img">
                            <img src="assets/images/ch1.jpg" alt="" class="radius-image">
                            <div class="overlay-team">
                                <div class="team-details text-center">
                                    <div class="socials mt-20">
                                        <a href="#url">
                                            <span class="fa fa-facebook-f"></span>
                                        </a>
                                        <a href="#url">
                                            <span class="fa fa-twitter"></span>
                                        </a>
                                        <a href="#url">
                                            <span class="fa fa-instagram"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#url" class="team-title">Pierre Marcolini</a>
                        <p>Experienced Chef</p>
                    </div>
                </div>
                <!-- end team member -->

                <div class="col-lg-3 col-6 team-wrap">
                    <div class="team-member text-center">
                        <div class="team-img">
                            <img src="assets/images/2ch.jpg" alt="" class="radius-image">
                            <div class="overlay-team">
                                <div class="team-details text-center">
                                    <div class="socials mt-20">
                                        <a href="#url">
                                            <span class="fa fa-facebook-f"></span>
                                        </a>
                                        <a href="#url">
                                            <span class="fa fa-twitter"></span>
                                        </a>
                                        <a href="#url">
                                            <span class="fa fa-instagram"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#url" class="team-title">Jennifer Yee</a>
                        <p>Experienced Chef</p>
                    </div>
                </div>
                <!-- end team member -->

                <div class="col-lg-3 col-6 team-wrap mt-lg-0 mt-5">
                    <div class="team-member last text-center">
                        <div class="team-img">
                            <img src="assets/images/man1.jpg" alt="" class="radius-image">
                            <div class="overlay-team">
                                <div class="team-details text-center">
                                    <div class="socials mt-20">
                                        <a href="#url">
                                            <span class="fa fa-facebook-f"></span>
                                        </a>
                                        <a href="#url">
                                            <span class="fa fa-twitter"></span>
                                        </a>
                                        <a href="#url">
                                            <span class="fa fa-instagram"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#url" class="team-title">Cyril </a>
                        <p>Manager</p>
                    </div>
                </div>
                <!-- end team member -->

                <div class="col-lg-3 col-6 team-wrap mt-lg-0 mt-5">
                    <div class="team-member last text-center">
                        <div class="team-img">
                            <img src="assets/images/ch3.jpg" alt="" class="radius-image">
                            <div class="overlay-team">
                                <div class="team-details text-center">
                                    <div class="socials mt-20">
                                        <a href="#url">
                                            <span class="fa fa-facebook-f"></span>
                                        </a>
                                        <a href="#url">
                                            <span class="fa fa-twitter"></span>
                                        </a>
                                        <a href="#url">
                                            <span class="fa fa-instagram"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#url" class="team-title">Sara </a>
                        <p>Experienced Staff</p>
                    </div>
                </div>
                <!-- end team member -->

            </div>
        </div>
</section>
<!--//team-sec-->
<!-- stats -->
<section class="w3_stats py-5" id="stats">
    <div class="container py-lg-5 py-md-4 py-2">
        <div class="title-content text-center">
            <h6 class="title-small">Our facts</h6>
            <h3 class="title-big">Why we are unique? Have a look.</h3>
        </div>
        <div class="w3-stats">
            <div class="row">
                <div class="col-md-3 col-6">
                    <div class="counter">
                        <span class="fa fa-comments"></span>
                        <div class="timer count-title count-number mt-3" data-to="15100" data-speed="1500"></div>
                        <p class="count-text "> Reviews </p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="counter">
                        <span class="fa fa-cutlery"></span>
                        <div class="timer count-title count-number mt-3" data-to="19256" data-speed="1500"></div>
                        <p class="count-text ">Orders Served</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="counter">
                        <span class="fa fa-smile-o"></span>
                        <div class="timer count-title count-number mt-3" data-to="12100" data-speed="1500"></div>
                        <p class="count-text ">Happy Customers</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="counter">
                        <span class="fa fa-users"></span>
                        <div class="timer count-title count-number mt-3" data-to="2560" data-speed="1500"></div>
                        <p class="count-text ">Daily Customers</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- //stats -->


<!-- testimonials -->
<section class="w3l-clients-1" id="testimonials">
    <!-- /grids -->
    <div class="cusrtomer-layout py-5">
        <div class="container py-lg-5 py-md-4 py-2">
            <div class="heading align-self text-center">
                <h6 class="title-small">What our customers Say</h6>
                <h3 class="title-big mb-md-5 mb-4">Customer Testimonials</h3>
            </div>
            <!-- /grids -->
            <div class="testimonial-row py-md-4">
                <div id="owl-demo1" class="owl-two owl-carousel owl-theme mb-md-3 mb-sm-5 mb-4">
                    <div class="item">
                        <div class="testimonial-content">
                            <div class="testimonial">
                                <div class="testi-stars">
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star-half"></span>
                                </div>
                                <blockquote>
                                    <q>"I have been a loyal customer of this bakery for years, and their pastries never fail to impress me. The variety of flavors they offer is outstanding, and each pastry is a work of art. The quality is consistently excellent, and the taste is simply delightful. I especially love their flaky croissants and perfectly sweetened danishes. The staff is always friendly and accommodating, making every visit a pleasant experience. I highly recommend indulging in their pastries - you won't be able to resist coming back for more!</q>
                                </blockquote>
                                <div class="testi-des">
                                    <div class="peopl align-self">
                                        <h3>Karien Kape</h3>
                                        <p class="indentity">Customer </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonial-content">
                            <div class="testimonial">
                                <div class="testi-stars">
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star-o"></span>
                                </div>
                                <blockquote>
                                    <q>"I recently discovered this bakery and I am so glad I did! Their pastries are absolutely heavenly. From their buttery, melt-in-your-mouth croissants to their decadent chocolate eclairs, every bite is a little piece of heaven. The flavors are perfectly balanced, and the texture is just right. The staff is knowledgeable and always willing to offer recommendations. The prices are reasonable for the quality you get. Do yourself a favor and try their pastries - your taste buds will thank you!
.</q>
                                </blockquote>
                                <div class="testi-des">
                                    <div class="peopl align-self">
                                        <h3>Nanny Mills</h3>
                                        <p class="indentity">Customer </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonial-content">
                            <div class="testimonial">
                                <div class="testi-stars">
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                                <blockquote>
                                    <q> "I had high expectations for this bakery's pastries, and they did not disappoint. The attention to detail in their creations is impressive. The pastries are not only visually appealing but also incredibly delicious. The flavors are rich and authentic, and the textures are perfectly balanced. The service was friendly and efficient, and the ordering process was quick and convenient. If you're a pastry lover like me, this bakery is a must-visit. You won't regret it!
</q>
                                </blockquote>
                                <div class="testi-des">
                                    <div class="peopl align-self">
                                        <h3>Lincy Sander</h3>
                                        <p class="indentity">Customer</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonial-content">
                            <div class="testimonial">
                                <div class="testi-stars">
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                                <blockquote>
                                    <q>"The pastries from this bakery are simply divine. I love how they offer a wide range of options, from classic pastries to more unique flavors. Each one is beautifully crafted with the utmost care. The taste is exceptional, with the perfect amount of sweetness. The staff is always welcoming and provides outstanding customer service. I appreciate how quickly they can accommodate large orders without compromising on quality. Treat yourself to their pastries - it's a delightful experience!</q>
                                </blockquote>
                                <div class="testi-des">
                                    <div class="peopl align-self">
                                        <h3>Deiv Thimmy</h3>
                                        <p class="indentity">Customer</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /grids -->
    </div>
    <!-- //grids -->
</section>
<!-- //testimonials -->
    <!-- forms -->
    <section class="w3l-forms-9 py-5" id="">
        <div class="main-w3 py-lg-3">
            <div class="container">
                <div class="row align-items-center">
                    <div class="main-midd col-lg-8">
                        <h3 class="title-big">Do You want to Share Your Experience with us. Then Don't Hesitate!</h3>
                    </div>
                    <div class="main-midd-2 col-lg-4 mt-lg-0 mt-4 text-lg-right">
                        <a class="btn btn-white btn-style" href="contact.php"> Review </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //forms -->
<!-- footer -->
<footer class="py-5">
  <div class="container py-xl-4">
    <div class="row footer-top">
      <div class="col-lg-4 footer-grid_section_1its footer-text">
        <!-- logo -->
        <h2>
          <a class="logo text-wh" href="index.php">
            <img src="assets/images/logo1.png" alt="burger logo" width="55px" /> Midnight Pastelería


          </a>
        </h2>
        <!-- //logo -->
        <p class="mt-lg-4 mt-3 mb-4 pb-lg-2">Ensuring the safety of our customers is of paramount importance at our pastry shop. We take rigorous measures to maintain a hygienic and secure environment. Our staff receives comprehensive training in food safety protocols, including proper handling, storage, and preparation techniques.</p>
        <!-- social icons -->
        <ul class="top-right-info">
          <li>
            <p>Follow us:</p>
          </li>
          <li class="facebook-w3">
            <a href="#facebbok">
              <span class="fa fa-facebook-f"></span>
            </a>
          </li>
          <li class="twitter-w3">
            <a href="#twitter">
              <span class="fa fa-twitter"></span>
            </a>
          </li>
          <li class="google-w3">
            <a href="#google">
              <span class="fa fa-google-plus"></span>
            </a>
          </li>
          <li class="dribble-w3">
            <a href="#dribble">
              <span class="fa fa-dribbble"></span>
            </a>
          </li>
        </ul>
        <!-- //social icons -->
      </div>
      <div class="col-lg-4 col-sm-6 footer-grid_section_1its mt-lg-0 mt-5">
        <div class="footer-title">
          <h3>Contact Us</h3>
        </div>
        <div class="footer-text mt-4">
          <p><strong>Address :</strong> Shwe Taung Kyar street, Near the Embassy of Italy, Yangon, Myanmar
            YNG - 11211.</p>
          <p class="my-2"><strong>Phone :</strong> <a href="tel:+95 971 912 102">+95 971 912 102</a></p>
          <p><strong>Email :</strong> <a href="mailto: mnpastelería@email.com">mnpastelería@email.com</a></p>
        </div>
        <div class="footer-title mt-4 pt-md-2">
          <h3>Payments we accept</h3>
        </div>
        <ul class="list-unstyled payment-links mt-4">
          <li>
            <a href="#payment"><img src="assets/images/pay2.png" class="radius-image" width="55px" alt=""></a>
          </li>
          <li>
            <a href="#payment"><img src="assets/images/pay5.png" class="radius-image" width="55px" alt=""></a>
          </li>
          <li>
            <a href="#payment"><img src="assets/images/pay1.png" class="radius-image" width="55px" alt=""></a>
          </li>
          <li>
            <a href="#payment"><img src="assets/images/pay4.png" class="radius-image" width="55px" alt=""></a>
          </li>
        </ul>
      </div>
      <div class="col-lg-4 col-sm-6 footer-grid_section_1its footer-text mt-lg-0 mt-5">
        <div class="footer-title">
          <h3>Login to order</h3>
        </div>
        <div class="info-form-right mt-4 p-0">
          <p class="mb-4">Enter your username and password the latest news, updates and special offers from us.</p>
          <form action="login_process.php" method="POST" enctype="multipart/form-data">
            <div class="form-group mb-2">
              
            <div>
                <!-- <label for="usern">Username:</label> -->
			    <input type="text" class="form-control" name="usern" id="usern" placeholder="Username" required>

		    </div>
		    <br>

            <div>
              <!-- <label for="passw">Password:</label> -->
			    <input type="password" class="form-control" name="passw" id='passw'placeholder="Password" required>

		    </div>
		    
              <!-- <input type="email" class="form-control" name="Email" placeholder="Email" required=""> -->
<br>
              <!-- <input type="password" class="form-control" name="Password" placeholder="Password" required=""> -->

            </div>
            <button type="submit" class="btn btn-style btn-primary w-100 d-block ml-auto py-2" value= 'Entry'>Login</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- //footer -->
<!-- copyright -->
<div class="cpy-right text-center py-4">
  <p>© 2020 Midnight Pastelería. All rights reserved </p>
</div>
<!-- //copyright -->

 <!-- move top -->
 <button onclick="topFunction()" id="movetop" title="Go to top">
  <span class="fa fa-level-up" aria-hidden="true"></span>
</button>
<script>
  // When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function () {
    scrollFunction()
  };

  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      document.getElementById("movetop").style.display = "block";
    } else {
      document.getElementById("movetop").style.display = "none";
    }
  }

  // When the user clicks on the button, scroll to the top of the document
  function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
</script>
<!-- /move top -->

<script src="assets/js/jquery-3.3.1.min.js"></script> <!-- Common jquery plugin -->

<script src="assets/js/theme-change.js"></script><!-- theme switch js (light and dark)-->

<script src="assets/js/owl.carousel.js"></script><!-- owl carousel -->

<!-- script for tesimonials carousel slider -->
<script>
  $(document).ready(function () {
    $("#owl-demo1").owlCarousel({
      loop: true,
      margin: 20,
      nav: false,
      responsiveClass: true,
      responsive: {
        0: {
          items: 1,
          nav: false
        },
        1000: {
          items: 1,
          nav: false,
          loop: false
        }
      }
    })
  })
</script>
<!-- //script for tesimonials carousel slider -->

<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script>
  $(document).ready(function () {
    $('.popup-with-zoom-anim').magnificPopup({
      type: 'inline',

      fixedContentPos: false,
      fixedBgPos: true,

      overflowY: 'auto',

      closeBtnInside: true,
      preloader: false,

      midClick: true,
      removalDelay: 300,
      mainClass: 'my-mfp-zoom-in'
    });

    $('.popup-with-move-anim').magnificPopup({
      type: 'inline',

      fixedContentPos: false,
      fixedBgPos: true,

      overflowY: 'auto',

      closeBtnInside: true,
      preloader: false,

      midClick: true,
      removalDelay: 300,
      mainClass: 'my-mfp-slide-bottom'
    });
  });
</script>

<script src="assets/js/counter.js"></script>

<!-- gallery popup js -->
<script src="assets/js/smartphoto.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    const sm = new SmartPhoto(".js-img-viwer", {
      showAnimation: false
    });
    // sm.destroy();
  });
</script>
<!-- //gallery popup js -->

<!--/MENU-JS-->
<script>
  $(window).on("scroll", function () {
    var scroll = $(window).scrollTop();

    if (scroll >= 80) {
      $("#site-header").addClass("nav-fixed");
    } else {
      $("#site-header").removeClass("nav-fixed");
    }
  });

  //Main navigation Active Class Add Remove
  $(".navbar-toggler").on("click", function () {
    $("header").toggleClass("active");
  });
  $(document).on("ready", function () {
    if ($(window).width() > 991) {
      $("header").removeClass("active");
    }
    $(window).on("resize", function () {
      if ($(window).width() > 991) {
        $("header").removeClass("active");
      }
    });
  });
</script>
<!--//MENU-JS-->

<!-- disable body scroll which navbar is in active -->
<script>
  $(function () {
    $('.navbar-toggler').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- //disable body scroll which navbar is in active -->

<!--bootstrap-->
<script src="assets/js/bootstrap.min.js"></script>
<!-- //bootstrap-->

</body>

</html>