
<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql="create table admin(Admin_Id integer primary key auto_increment, Username varchar(100)not null , Password varchar(100)not null)";

	// if(mysqli_query($connection,$sql))
	// 	echo "Admin table is created!";

	// else echo "Error is found";


 ?>

<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql="create table offer(Offer_Id integer primary key auto_increment, Offer_iteams varchar(100) not null , Orignal_Price varchar(1000)not null ,Price varchar(1000)not null , Description varchar(500)not null)";

	// if(mysqli_query($connection,$sql))
	// 	echo "Offer table is created!";

	// else echo "Error is found";



?>
<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql="create table cus(Cus_Id integer primary key auto_increment, Name varchar(100) not null , Email varchar(100)not null , Username varchar(100)not null , Password varchar(100)not null)";

	// if(mysqli_query($connection,$sql))
	// 	echo "User table is created!";

	// else echo "Error is found";



?>
<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql="create table pastries(Pastries_Id integer primary key auto_increment, Pastries_iteams varchar(100) not null,Price varchar(1000)not null , Description varchar(500)not null)";

	// if(mysqli_query($connection,$sql))
	// 	echo "Offer table is created!";

	// else echo "Error is found";



?>
<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql="create table appetizers(Appetizers_Id integer primary key auto_increment, Appetizers_iteams varchar(100) not null,Price varchar(1000)not null , Description varchar(500)not null)";

	// if(mysqli_query($connection,$sql))
	// 	echo "Appetizers table is created!";

	// else echo "Error is found";



?>
<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql="create table cake(Cake_Id integer primary key auto_increment, Cake_iteams varchar(100) not null,Price varchar(1000)not null , Description varchar(500)not null)";

	// if(mysqli_query($connection,$sql))
	// 	echo "Cake table is created!";

	// else echo "Error is found";



?>

<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql="create table cold(Cold_Id integer primary key auto_increment, Cold_iteams varchar(100) not null,Price varchar(1000)not null , Description varchar(500)not null)";

	// if(mysqli_query($connection,$sql))
	// 	echo "Cold table is created!";

	// else echo "Error is found";



?>

<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql="create table hot(Hot_Id integer primary key auto_increment, Hot_iteams varchar(100) not null,Price varchar(1000)not null , Description varchar(500)not null)";

	// if(mysqli_query($connection,$sql))
	// 	echo "Hot table is created!";

	// else echo "Error is found";



?>

<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql="create table wine(Wine_Id integer primary key auto_increment, Wine_iteams varchar(100) not null,Price varchar(1000)not null , Description varchar(500)not null)";

	// if(mysqli_query($connection,$sql))
	// 	echo "Wine table is created!";

	// else echo "Error is found";

?>

<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql = "CREATE TABLE `iteams` (
	// 	`Iteams_Id` INT NOT NULL AUTO_INCREMENT,
	// 	`Pastries_Id` INT,
	// 	`Appetizers_Id` INT,
	// 	`Cake_Id` INT,
	// 	`Cold_Id` INT,
	// 	`Hot_Id` INT,
	// 	`Wine_Id` INT,
	// 	`Offer_Id` INT,
	// 	`Quality` VARCHAR(1000) NOT NULL,
	// 	`Price` VARCHAR(100) NOT NULL,
	// 	PRIMARY KEY (`Iteams_Id`),
	// 	FOREIGN KEY (`Pastries_Id`) REFERENCES `pastries`(`Pastries_Id`),
	// 	FOREIGN KEY (`Appetizers_Id`) REFERENCES `appetizers`(`Appetizers_Id`),
	// 	FOREIGN KEY (`Cake_Id`) REFERENCES `cake`(`Cake_Id`),
	// 	FOREIGN KEY (`Cold_Id`) REFERENCES `cold`(`Cold_Id`),
	// 	FOREIGN KEY (`Hot_Id`) REFERENCES `hot`(`Hot_Id`),
	// 	FOREIGN KEY (`Wine_Id`) REFERENCES `wine`(`Wine_Id`),
	// 	FOREIGN KEY (`Offer_Id`) REFERENCES `offer`(`Offer_Id`)
	// )";

	// if(mysqli_query($connection,$sql))
	// 	echo "check-out table is created!";

	// else echo "Error is found";


?>
<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql = "CREATE TABLE `check-out` (
	// 	`Check-out_Id` INT NOT NULL AUTO_INCREMENT,
	// 	`Cus_Id` INT,
	// 	`Items_Id` INT,
	// 	`Price` VARCHAR(100) NOT NULL,
	// 	`Charge` VARCHAR(1000) NOT NULL,
	// 	PRIMARY KEY (`Check-out_Id`),
	// 	FOREIGN KEY (`Cus_Id`) REFERENCES `cus`(`Cus_Id`),
	// 	FOREIGN KEY (`Items_Id`) REFERENCES `iteams`(`Iteams_Id`)
	// )";

	// if(mysqli_query($connection,$sql))
	// 	echo "check-out table is created!";

	// else echo "Error is found";


?>
<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	// $sql = "CREATE TABLE `order` (
	// 	`Order_Id` INT NOT NULL AUTO_INCREMENT,
	// 	`Cus_Id` INT,
	// 	`Admin_Id` INT,
	// 	`Items_Id` INT,
	// 	`Check-out_Id` INT,
	// 	`Price` VARCHAR(100) NOT NULL,
	// 	PRIMARY KEY (`Order_Id`),
	// 	FOREIGN KEY (`Cus_Id`) REFERENCES `cus`(`Cus_Id`),
	// 	FOREIGN KEY (`Admin_Id`) REFERENCES `admin`(`Admin_Id`),
	// 	FOREIGN KEY (`Items_Id`) REFERENCES `iteams`(`Iteams_Id`),
	// 	FOREIGN KEY (`Check-out_Id`) REFERENCES `check-out`(`Check-out_Id`)
	// )";

	// if(mysqli_query($connection,$sql))
	// 	echo "order table is created!";

	// else echo "Error is found";


?>

<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	
	// $sql = "CREATE TABLE `review` (
	// 	`Review_Id` INT NOT NULL AUTO_INCREMENT,
	// 	`Cus_Id` INT,
	// 	`Name` VARCHAR(100) NOT NULL,
	// 	`Email` VARCHAR(100) NOT NULL,
	// 	`Message` VARCHAR(1000) NOT NULL,
	// 	PRIMARY KEY (`Review_Id`),
	// 	FOREIGN KEY (`Cus_Id`) REFERENCES `cus`(`Cus_Id`)
	// )";

	// // $sql="create table Review(Review_Id integer primary key auto_increment, Cus_Id integer auto_increment, Name varchar(100), Email varchar(100) not null, Message varchar(1000) not null)";

	// if(mysqli_query($connection,$sql))
	// 	echo "Review table is created!";

	// else echo "Error is found";


?>
<?php
	// $host = "localhost";
	// $username="root";
	// $password="";
	// $dbname="pastrydb";

	// $connection=mysqli_connect($host,$username,$password,$dbname);

	
	// $sql = "create table category(Category_Id integer primary key auto_increment, Category_Name varchar (200) not null, Type varchar(200) not null)" ;

	// // $sql="create table Review(Review_Id integer primary key auto_increment, Cus_Id integer auto_increment, Name varchar(100), Email varchar(100) not null, Message varchar(1000) not null)";

	// if(mysqli_query($connection,$sql))
	// 	echo "Category table is created!";

	// else echo "Error is found";


?>
<?php
// $host = "localhost";
// $username="root";
// $password="";
// $dbname="pastrydb";

// $connection=mysqli_connect($host,$username,$password,$dbname);


// $sql = "create table items(Item_Id integer primary key auto_increment, Item_Name varchar (500) not null, Price varchar(500) not null, Description varchar(500) not null,Category_Id integer ,FOREIGN KEY (`Category_Id`) REFERENCES `category`(`Category_Id`) )" ;

// // $sql="create table Review(Review_Id integer primary key auto_increment, Cus_Id integer auto_increment, Name varchar(100), Email varchar(100) not null, Message varchar(1000) not null)";

// if(mysqli_query($connection,$sql))
// 	echo "item table is created!";

// else echo "Error is found";
?>
<?php
$host = "localhost";
$username="root";
$password="";
$dbname="pastrydb";

$connection=mysqli_connect($host,$username,$password,$dbname);


$sql = "create table check_out(Check_out_Id integer primary key auto_increment, Name varchar (500) not null,Item_Name varchar(500) not null, Price varchar(500) not null ,Charges varchar(500) not null)" ;

// $sql="create table Review(Review_Id integer primary key auto_increment, Cus_Id integer auto_increment, Name varchar(100), Email varchar(100) not null, Message varchar(1000) not null)";

if(mysqli_query($connection,$sql))
	echo "check-out table is created!";

else echo "Error is found";
?>



