<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Register Process</title>
</head>
<body>
	<?php
	include("connection.php");
		
		$fname = trim($_POST["fname"]);
		$email = trim($_POST["email"]);
		$user = trim($_POST["user"]);
		$passw = trim($_POST["pass"]);

		$usern = trim($_POST["usern"]);
		$passw = trim($_POST["passw"]);


		
		if ($pass== $pass) 
		{
			$sql_existing_user ="select * from cus where username='$user'";
			
			$result = mysqli_query($connection,$sql_existing_user);
			
			$num_rows=mysqli_num_rows($result);

			if($num_rows==0){

			

				$sql="insert into cus(Name,Email, Username, Password) values( '$fname','$email', '$user', '$pass')";

				if(mysqli_query($connection,$sql))
					echo " Register Successful! <script>window.location='Login.php'</script>";


				else {echo "Error is found";}

			}

			else
			{
			  echo "Existed username! Please Login with other username again <br>"; 
			}
		}
		if ($passw== $passw) {
			$sql_existing_user ="select * from admin where username='$user1'";
		
			$result = mysqli_query($connection,$sql_existing_user);
		
			$num_rows=mysqli_num_rows($result);

		}
		if($num_rows==0){

				$sql="insert into admin(Username, Password) values('$user1', '$pass1')";

				if(mysqli_query($connection,$sql))
					echo " Register Successful! <script>window.location='Login.php'</script>";


				else {echo "Error is found";}

			}
			else{
			echo "Passwords do not match! Try again...";
			}
	
		// else{
		// 	echo "Passwords do not match! Try again...";
		// }
			
//sitekey="6Lc0n40mAAAAAECs8_IY2TpqCPNNa57PBcC4A1qV"
//$secretKey = "6Lc0n40mAAAAAMAoPr9sAsv_hL15Mg5IEtdazucZ";

 



if(isset($_POST['g-recaptcha-response'])){
	$captcha=$_POST['g-recaptcha-response'];
}



  if(!$captcha){
	echo '<h2>Please check the the captcha form.</h2>';
	exit;
  }



  $secretKey = "6Lc0n40mAAAAAMAoPr9sAsv_hL15Mg5IEtdazucZ";



  $ip = $_SERVER['REMOTE_ADDR'];



  // post request to server
  $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);



  $response = file_get_contents($url);
  $responseKeys = json_decode($response,true);



  // should return JSON with success as true
  if($responseKeys["success"]) {
		  echo '<h2>Regeisterd User</h2>';
  } else {
		  echo '<h2>reCaptcha verification failed.</h2>';
  }

 

  
?>

	

</body>
</html>