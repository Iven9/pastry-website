<?php
function IndexOf($item_id)
{
    foreach ($_SESSION['Shopping_Cart1'] as $key => $value) {
        if ($value['Item_Id'] == $item_id) {
            return $key;
        }
    }
    return -1;
}
function RemoveItem($Item_Id) {
    if (isset($_SESSION['Shopping_Cart1'])) {
        $index = IndexOf($Item_Id);

        if ($index !== -1) {
            unset($_SESSION['Shopping_Cart1'][$index]); // Remove the item from the session array
            $_SESSION['Shopping_Cart1'] = array_values($_SESSION['Shopping_Cart1']); // Re-index the array
        }
    }
    }

    function ClearAll() {
        if (isset($_SESSION['Shopping_Cart1'])) {
            unset($_SESSION['Shopping_Cart1']); // Remove the entire session variable
        }
        echo "<script>window.location='Shopping_Cart1.php'</script>";
    }  
    function CalculateTotalAmount()
{
    $TotalAmount = 0;

    $size = count($_SESSION['Shopping_Cart1']);

    for ($i = 0; $i < $size; $i++) {
        // Remove dollar sign and convert to float
        $Price = floatval(str_replace('$', '', $_SESSION['Shopping_Cart1'][$i]['Price']));
        $BuyQuantity = $_SESSION['Shopping_Cart1'][$i]['BuyQuantity'];

        // Debugging output
        // echo "Index: $i, Price: $Price, BuyQuantity: $BuyQuantity<br>";

        $TotalAmount += $Price * $BuyQuantity;
    }

    return $TotalAmount;
}

function CalculateTotalQuantity()
{
	$TotalQuantity=0;

	$size=count($_SESSION['Shopping_Cart1']);

	for($i=0;$i<$size;$i++) 
	{ 
		$BuyQuantity=$_SESSION['Shopping_Cart1'][$i]['BuyQuantity'];
		$TotalQuantity=$TotalQuantity + ($BuyQuantity);
	}
	return $TotalQuantity;
}  
    function AddItem($Item_Id, $BuyQuantity)
    {
        include('connection.php');
    
        $query = "SELECT Item_Id, Item_Name, Price FROM items WHERE Item_Id = ?";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, 'i', $Item_Id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
    
        // Check if the query was successful
        if (!$result) {
            echo "<p>Error executing query: " . mysqli_error($connection) . "</p>";
            exit();
        }
    
        $row = mysqli_fetch_array($result);
    
        $count = mysqli_num_rows($result);
    
        if ($count < 1) {
            echo "<p>No item found!</p>";
            exit();
        }
    
        if ($BuyQuantity < 1) {
            echo "<script>window.alert('Please enter a correct quantity.')</script>";
            echo "<script>window.location='menu.php'</script>";
        }
    
        if (isset($_SESSION['Shopping_Cart1'])) {
            $index = IndexOf($Item_Id);
    
            if ($index == -1) {
                $size = count($_SESSION['Shopping_Cart1']);
                $_SESSION['Shopping_Cart1'][$size]['Item_Id'] = $Item_Id;
                $_SESSION['Shopping_Cart1'][$size]['BuyQuantity'] = $BuyQuantity;
    
                $_SESSION['Shopping_Cart1'][$size]['Price'] = $row['Price'];
                $_SESSION['Shopping_Cart1'][$size]['Item_Name'] = $row['Item_Name'];
            } else {
                $_SESSION['Shopping_Cart1'][$index]['BuyQuantity'] += $BuyQuantity;
            }
        } else {
            $_SESSION['Shopping_Cart1'] = array();
    
            $_SESSION['Shopping_Cart1'][0]['Item_Id'] = $Item_Id;
            $_SESSION['Shopping_Cart1'][0]['BuyQuantity'] = $BuyQuantity;
    
            $_SESSION['Shopping_Cart1'][0]['Price'] = $row['Price'];
            $_SESSION['Shopping_Cart1'][0]['Item_Name'] = $row['Item_Name'];
        }
    
        // Output for debugging
        echo "Item added to cart: ";
        print_r($_SESSION['Shopping_Cart1']);
    
        // Redirect to the shopping cart page
        echo "<script>window.location='Shopping_Cart1.php'</script>";
    }



?>