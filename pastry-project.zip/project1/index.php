<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Midnight Pastelería</title>


    <link href="//fonts.googleapis.com/css2?family=Dosis:wght@300;400;500;600;800&display=swap" rel="stylesheet">

    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
  </head>
  <body>
<!--header-->
<header id="site-header" class="fixed-top">
  <div class="container">
      <nav class="navbar navbar-expand-lg stroke px-0">
          <h1> <a class="navbar-brand" href="index.php">
              <img src="assets/images/logo1.png" alt="burger logo"width="55px" /> Midnight Pastelería 
              </a></h1>
          <!-- if logo is image enable this   
  <a class="navbar-brand" href="#index.php">
      <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
  </a> -->
          <button class="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse"
              data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"
              aria-label="Toggle navigation">
              <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
              <span class="navbar-toggler-icon fa icon-close fa-times"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul class="navbar-nav ml-auto">
                  <li class="nav-item active">
                      <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item @@about__active">
                      <a class="nav-link" href="about.php">About</a>
                  </li>
                  <li class="nav-item @@menu__active">
                      <a class="nav-link" href="menu.php">Menu</a>
                  </li>
                  <li class="nav-item @@contact__active">
                      <a class="nav-link" href="contact.php">Contact</a>
                  </li>
                  <li class="nav-item @@contact__active">
                      <a class="nav-link" href="login.php">Login</a>
                  </li>
                  <li class="nav-item @@contact__active">
                      <a class="nav-link" href="login_staff.php">Staff</a>
                  </li>
                  <!--/search-right-->
                  <div class="search-right">
                      <a href="#search" title="search"><span class="fa fa-search" aria-hidden="true"></span></a>
                      <!-- search popup -->
                      <div id="search" class="pop-overlay">
                          <div class="popup">
                              <h4 class="mb-3">Search here</h4>
                              <form action="error.php" method="GET" class="search-box">
                                  <input type="search" placeholder="Enter Keyword" name="search" required="required"
                                      autofocus="">
                                  <button type="submit" class="btn btn-style btn-primary">Search</button>
                              </form>

                          </div>
                          <a class="close" href="#close">×</a>
                      </div>
                      <!-- /search popup -->
                  </div>
                  <!--//search-right-->
              </ul>
          </div>
          <!-- toggle switch for light and dark theme -->
          <div class="mobile-position">
              <nav class="navigation">
                  <div class="theme-switch-wrapper">
                      <label class="theme-switch" for="checkbox">
                          <input type="checkbox" id="checkbox">
                          <div class="mode-container">
                              <i class="gg-sun"></i>
                              <i class="gg-moon"></i>
                          </div>
                      </label>
                  </div>
              </nav>
          </div>
          <!-- //toggle switch for light and dark theme -->
      </nav>
  </div>
</header>
<!--/header-->
<!-- banner section -->
<section id="home" class="w3l-banner py-5">
    <div class="container py-lg-5 py-md-4 mt-lg-0 mt-md-5 mt-4">
        <div class="row align-items-center py-lg-5 py-4 mt-4">
            <div class="col-lg-6 col-sm-12">
                <h3 class="">A Slice of Heaven. </h3>
                <h2 class="mb-4"> Freshly Baked All Day and Every day</h2>
                <p> Orgin Taste of Italian</p>
                <div class="mt-md-5 mt-4">
                    <a class="btn btn-primary btn-style mr-2" href="menu.php"> See Menu </a>
                    <a class="btn btn-outline-primary btn-style" href="#call"> Book a table </a>
                </div>
            </div>
            <div class="col-lg-5">
            </div>
        </div>
    </div>
</section>
<!-- //banner section -->
<section class="w3l-index3" id="work">
    <div class="midd-w3 py-5">
        <div class="container py-lg-5 py-md-4 py-2">
            <div class="row">
                <div class="col-lg-6 left-wthree-img text-righ">
                    <div class="position-relative">
                        <img src="assets/images/3.jpg" alt="" class="img-fluid radius-image-full">
                        <a href="#small-dialog" class="popup-with-zoom-anim play-view text-center position-absolute">
                            <span class="video-play-icon">
                                <span class="fa fa-play"></span>
                            </span>
                        </a>
                        <!-- dialog itself, mfp-hide class is required to make dialog hidden -->
                        <div id="small-dialog" class="zoom-anim-dialog mfp-hide">
                            <!-- <iframe src="https://www.youtube.com/embed/dCVEY88Fn1k" allow="autoplay; fullscreen" allowfullscreen=""></iframe> -->
                              <img src= "assets/images/3.jpg" allow="autoplay; fullscreen" allowfullscreen="" width="660px"></img>

                        </div>
                    </div>
                </div>
                <div class="col-lg-6 mt-lg-0 mt-md-5 mt-4 about-right-faq align-self">
                    <h5 class="title-small mb-1">Our story</h5>
                    <h3 class="title-big">Welcome to  <span>Midnight Pastelería </span></h3>
                    <p class="mt-sm-4 mt-3">Yangon Midnight Pastelería opened its first location near Embassy of Italy in Shwe Taung Kyar street in 1999, marking the start of the coffee shop's existence. In addition to pastries, the shop also offered roasted coffee beans, tea, and spices. The seafaring tradition of early coffee and pastry vendors served as the inspiration for the name "Pastelera." After introducing to the kindness and skill of Italian pastry culture, New Yorker Hardin Scott joined the company in 2009. Pastelera is a historical hub for artisanal baking, not merely a coffee shop</p>
                    <a class="btn btn-primary btn-style mt-md-5 mt-4 mr-2" href="about.php"> Read More </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- /bottom-grids-->
<section class="w3l-bottom-grids-6 py-5">
    <div class="container py-lg-5 py-md-4 py-2">
        <div class="grids-area-hny main-cont-wthree-fea row">
            <div class="col-lg-4 col-md-6 grids-feature">
                <div class="area-box">
                    <img src="assets/images/p1.png" alt="Pastries logo" width="88px">
                    <h4><a href="#feature" class="title-head">Pastries</a></h4>
                    <p class="mb-3">Cannoli ,Puff, Sfogliatella, Maritozzo, Bomboloni, Chiacchiere, Panettone,Zeppole di San Giuseppe, etc...</p>
                    <a href="menu.php" class="btn btn-text">View all </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 grids-feature mt-md-0 mt-4">
                <div class="area-box">
                    <img src="assets/images/a1.png" alt="Appetizers logo" width="95px">
                    <h4><a href="#feature" class="title-head">Appetizers</a></h4>
                    <p class="mb-3">Sweet Pea Pesto, Focaccia Barese, Slow-Cooked Italian Meatballs, Marinated Mozzarella & Tomato, etc...</p>
                    <a href="menu.php" class="btn btn-text">View all </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 grids-feature mt-md-0 mt-4">
                <div class="area-box">
                    <img src="assets/images/b11.png" alt="Cake logo" width="61px">
                    <h4><a href="#feature" class="title-head">Cake</a></h4>
                    <p class="mb-3">Italian Style Lemon Ricotta Cake, Chocolate Walnut Cake (Torta di Noci), Italian Orange Cake, etc...</p>
                    <a href="menu.php" class="btn btn-text">View all </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 grids-feature mt-lg-0 mt-4">
                <div class="area-box">
                    <img src="assets/images/co1.png" alt="Cold drink logo" width="95px">
                    <h4><a href="#feature" class="title-head">Cold</a></h4>
                    <p class="mb-3"> Ice-Americano, Ice-Latte, Caffè shakerato , Caffè leccese, Cold brew tonic, Affogato al caffèl, etc..</p>
                    <a href="menu.php" class="btn btn-text">View all </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 grids-feature mt-lg-0 mt-4">
                <div class="area-box">
                    <img src="assets/images/h1.png" alt="hot drink logo" width="77px">
                    <h4><a href="#feature" class="title-head">Hot</a></h4>
                    <p class="mb-3">Hot Apple Cinnamon Shrub Tea, Gingerbread Hot Cocoa ,Red Velvet Hot Chocolate, etc...</p>
                    <a href="menu.php" class="btn btn-text">View all </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 grids-feature mt-lg-0 mt-4">
                <div class="area-box">
                    <img src="assets/images/w1.png" alt="Wine logo" width="102px">
                    <h4><a href="#feature" class="title-head">Wine</a></h4>
                    <p class="mb-3">White Zinfandel ~ Albertoni, Prosecco, Merlot, Lambrusco , Conondrum, Barolo, Italy, etc...</p>
                    <a href="menu.php" class="btn btn-text">View all </a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- //bottom-grids-->

<!-- /mobile section --->
<section class="w3l-mobile-content-6 py-5">
    <div class="mobile-info py-lg-5 py-md-4 py-2">
        <!-- /mobile-info-->
        <div class="container">
            <div class="row mobile-info-inn mx-lg-0">
                <div class="col-lg-4 mobile-right">
                    <div class="row mobile-right-grids mb-lg-5 mb-4">
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                                <span class="fa fa-leaf"></span>
                            </div>
                        </div>
                        <div class="col-10 mobile-right-info">
                            <h6><a href="#url">Natural ingredients</a></h6>
                            <p>First and foremost, the key to a better cup of coffee is our coffee beans. Organic coffee is a healthier option for consumers since it is grown without the use of synthetic fertilisers and pesticides.</p>
                        </div>
                    </div>
                    <div class="row mobile-right-grids mb-lg-5 mb-4">
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                                <span class="fa fa-shopping-basket"></span>
                            </div>
                        </div>
                        <div class="col-10 mobile-right-info">
                            <h6><a href="#url"> Fresh vegetables & Meat</a></h6>
                            <p>All the food are made with day to day fresh vegetable and meat to give priority for the customer's health.</p>
                        </div>
                    </div>
                    <!-- <div class="row mobile-right-grids">
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                                <span class="fa fa-users"></span>
                            </div>
                        </div>
                        <div class="col-10 mobile-right-info">
                            <h6><a href="#url">World’s best Chef </a></h6>
                            <p>Lorem ipsum dolor sit amet,Ea sed illum facere aperiam sequi optio consec
                                adipisicing elit.</p>
                        </div>
                    </div> -->
                </div>
                <div class="col-lg-4 mobile-left">
                    <img src="assets/images/m22.png" class="img-fluid radius-image" alt="">
                </div>
                <div class="col-lg-4 mobile-right" style="margin-bottom: 50px;">
                    <div class="row mobile-right-grids mb-lg-5 mb-4">
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                                <span class="fa fa-cogs"></span>
                            </div>
                        </div>
                        <div class="col-10 mobile-right-info">
                            <h6><a href="#url">Best quality products</a></h6>
                            <p>The use of premium, fresh, and high-quality ingredients has a big influence on the pastries' taste and general quality. The flavours, textures, and overall pastry-eating experience for high-quality components.</p>
                        </div>
                    </div>
                    <!-- <div class="row mobile-right-grids mb-lg-5 mb-4">
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                                <span class="fa fa-motorcycle"></span>
                            </div>
                        </div>
                        <div class="col-10 mobile-right-info">
                            <h6><a href="#url">Fastest door delivery</a></h6>
                            <p>Lorem ipsum dolor sit amet,Ea sed illum facere aperiam sequi optio consec
                                adipisicing elit.</p>
                        </div>
                    </div> -->
                    <div class="row mobile-right-grids">
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                            <span class="fa fa-users"></span>
                            </div>
                        </div>
                        <div class="col-10 mobile-right-info">
                        <h6><a href="#url">World's best Chef </a></h6>
                            <p>The Symphony Cake, a sumptuous dessert that showcases our chef's talent for flavour balance in our pastry store.  .</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- //mobile-info-->
    </div>
</section>
<!-- //mobile section --->
<!-- middle -->

<!-- <style>
  .middle {
  background: url(../images/b1.jpg) no-repeat top;
  background-attachment: fixed;
  background-size: cover;
  -webkit-background-size: cover;
  -o-background-size: cover;
  -moz-background-size: cover;
  -ms-background-size: cover;
  position: relative;
  z-index: 1;
  }

</style> -->

<div class="middle py-5" id="call" >
    <div class="container py-lg-3">
        <div class="welcome-left text-center py-md-5 py-3">
            <h3>The Right Ingredients
                for the Right Food. Eat Healthy, Delicious and Perfect Pastry From Our Pastelería</h3>
            <h3 class="mt-4">Call us to order: <a href="tel:+95 971 912 102">+95 971 912 102</a> </h3>
            <a href="contact.php" class="btn btn-style btn-primary mt-sm-5 mt-4 mr-2">Contact Us</a>
            <a href="#book" class="btn btn-style btn-outline-primary mt-sm-5 mt-4">Book a table</a>
        </div>
    </div>
</div>
<!-- //middle -->
<!--  Work gallery section -->
<div class="w3l-gallery2" id="gallery">
    <div class="burger galleryks py-5">
      <div class="container py-lg-4 py-md-3">
        <h6 class="title-small text-center">Food Gallery</h6>
        <h3 class="title-big mb-lg-5 mb-4 text-center">Our Pastry Gallery</h3>
        <div class="row no-gutters masonry">
          <div class="col-lg-3 col-md-4 col-sm-6">
            <a href="assets/images/lr1.jpg"  class="js-img-viwer d-block" data-caption="The Right Ingredients for the Right Food."
              data-id="lion">
              <img src="assets/images/lr2.jpg" class="img-fluid radius-image-full" alt="burger gallery" />
              <div class="content-overlay"></div>
              <div class="content-details fadeIn-top">
                <span class="fa fa-plus" aria-hidden="true"></span>
                <h4>Delight your Best</h4>
              </div>
            </a>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6">
            <a href="assets/images/p1.jpg" class="js-img-viwer d-block" data-caption="The Right Ingredients for the Right Food."
              data-id="camel">
              <img src="assets/images/p12.jpg" class="img-fluid radius-image-full" alt="burger gallery" />
              <div class="content-overlay"></div>
              <div class="content-details fadeIn-top">
                <span class="fa fa-plus" aria-hidden="true"></span>
                <h4>Delight your Best</h4>
              </div>
            </a>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6">
            <a href="assets/images/mt1.jpg" class="js-img-viwer d-block" data-caption="The Right Ingredients for the Right Food."
              data-id="hippopotamus">
              <img src="assets/images/mt2.jpg" class="img-fluid radius-image-full" alt="burger gallery" />
              <div class="content-overlay"></div>
              <div class="content-details fadeIn-top">
                <span class="fa fa-plus" aria-hidden="true"></span>
                <h4>Delight your Best</h4>
              </div>
            </a>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6">
            <a href="assets/images/m1.jpg" class="js-img-viwer d-block" data-caption="The Right Ingredients for the Right Food."
              data-id="koala">
              <img src="assets/images/m11.jpg" class="img-fluid radius-image-full" alt="burger gallery" />
              <div class="content-overlay"></div>
              <div class="content-details fadeIn-top">
                <span class="fa fa-plus" aria-hidden="true"></span>
                <h4>Delight your Best</h4>
              </div>
            </a>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6">
            <a href="assets/images/m1 (2).jpg" class="js-img-viwer d-block" data-caption="The Right Ingredients for the Right Food."
              data-id="bear">
              <img src="assets/images/m.jpg" class="img-fluid radius-image-full" alt="burger gallery" />
              <div class="content-overlay"></div>
              <div class="content-details fadeIn-top">
                <span class="fa fa-plus" aria-hidden="true"></span>
                <h4>Delight your Best</h4>
              </div>
            </a>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6">
            <a href="assets/images/tn1.jpg" class="js-img-viwer d-block" data-caption="The Right Ingredients for the Right Food."
              data-id="rhinoceros">
              <img src="assets/images/tn12.jpg" class="img-fluid radius-image-full" alt="burger gallery" />
              <div class="content-overlay"></div>
              <div class="content-details fadeIn-top">
                <span class="fa fa-plus" aria-hidden="true"></span>
                <h4>Delight your Best</h4>
              </div>
            </a>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6">
            <a href="assets/images/31.jpg" class="js-img-viwer d-block" data-caption="The Right Ingredients for the Right Food."
              data-id="hippopotamus">
              <img src="assets/images/32.jpg" class="img-fluid radius-image-full" alt="burger gallery" />
              <div class="content-overlay"></div>
              <div class="content-details fadeIn-top">
                <span class="fa fa-plus" aria-hidden="true"></span>
                <h4>Delight your Best</h4>
              </div>
            </a>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6">
            <a href="assets/images/111.jpg" class="js-img-viwer d-block" data-caption="The Right Ingredients for the Right Food."
              data-id="koala">
              <img src="assets/images/211.jpg" class="img-fluid radius-image-full" alt="burger gallery" />
              <div class="content-overlay"></div>
              <div class="content-details fadeIn-top">
                <span class="fa fa-plus" aria-hidden="true"></span>
                <h4>Delight your Best</h4>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--  //Work gallery section -->


<!-- features -->
<section class="w3l-reasons py-5" id="why">
    <div class="main-w3 py-lg-5 py-md-d py-2">
        <div class="container">
            <div class="title-content text-center">
                <h6 class="title-small">Why we are the best</h6>
                <h3 class="title-big">4 Reasons to Choose us</h3>
            </div>
            <div class="row main-cont-wthree-fea mt-5 pt-lg-4 text-center">
                <div class="col-lg-3 col-sm-6 grids-feature">
                    <a href="#url" class="icon"><span class="fa fa-cutlery"></span></a>
                    <h4><a href="#feature" class="title-head">Tasty Pastry</a></h4>
                    <p>what makes our pastries truly delicious is the passion and love that goes into their creation.</p>
                </div>
                <div class="col-lg-3 col-sm-6 grids-feature mt-sm-0 mt-5">
                    <a href="#url" class="icon"><span class="fa fa-cogs"></span></a>
                    <h4><a href="#feature" class="title-head">Quality Products</a></h4>
                    <p>The use of premium, fresh, and high-quality ingredients has a big influence on the pastries' taste and general quality.</p>
                </div>
                <div class="col-lg-3 col-sm-6 grids-feature mt-lg-0 mt-sm-5 mt-5">
                    <a href="#url" class="icon"><span class="fa fa-users"></span></a>
                    <h4><a href="#feature" class="title-head">World's best Chef</a></h4>
                    <p>Our talented team of pastry chefs brings unparalleled creativity and expertise to the kitchen.</p>
                </div>
                <div class="col-lg-3 col-sm-6 grids-feature mt-lg-0 mt-sm-5 mt-5">
                    <a href="#url" class="icon"><span class="fa fa-shopping-basket"></span></a>
                    <h4><a href="#feature" class="title-head">Fastest order</a></h4>
                    <p>Our website offer a user-friendly online ordering experience, select desired items,and place it with just a few clicks.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- //features -->

<!-- app-4 
<section class="w3l-app-launch-4 py-5">
    <div id="app4-block" class="py-lg-5 py-md-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 app4-left-text">
                    <h5 class="title-small">Easy way to use mobile app</h5>
                    <h3 class="title-big">Download our mobile apps today</h3>
                    <p class="mt-3"> Suspendisse efficitur orci urna. In et augue ornare, tempor massa in, luctus
                        sapien. Proin a diam et dui fermentum molestie vel id neque. Donec sed tempus enim, 
                        a congue risus. euismod massa a quam interdum. </p>
                    <div class="download-btns mt-4 pt-lg-3">
                        <a href="#url"><img src="assets/images/appstore.png" class="radius-image" alt=""></a>
                        <a href="#url"><img src="assets/images/googleplay.png" class="radius-image" alt=""></a>
                    </div>
                    <span class="or"> or </span>
                    <div class="download-link">
                        <h5 class="mb-2">Enter your email to get download link</h5>
                        <form action="#" methos="GET" class="d-flex wrap-align">
                            <input type="email" placeholder="Enter email" required="required" />
                            <button type="submit">Get link</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6 app4-right-image mt-lg-0 mt-md-5 mt-4">
                    <img src="assets/images/mobile.jpg" class="img-fluid radius-image-full" alt="App Device" />
                </div>
            </div>
        </div>
    </div>
 </section> -->
<!-- footer -->
<footer class="py-5">
  <div class="container py-xl-4">
    <div class="row footer-top">
      <div class="col-lg-4 footer-grid_section_1its footer-text">
        <!-- logo -->
        <h2>
          <a class="logo text-wh" href="index.php">
            <img src="assets/images/logo1.png" alt="burger logo" width="55px" /> Midnight Pastelería


          </a>
        </h2>
        <!-- //logo -->
        <p class="mt-lg-4 mt-3 mb-4 pb-lg-2">Ensuring the safety of our customers is of paramount importance at our pastry shop. We take rigorous measures to maintain a hygienic and secure environment. Our staff receives comprehensive training in food safety protocols, including proper handling, storage, and preparation techniques.</p>
        <!-- social icons -->
        <ul class="top-right-info">
          <li>
            <p>Follow us:</p>
          </li>
          <li class="facebook-w3">
            <a href="#facebbok">
              <span class="fa fa-facebook-f"></span>
            </a>
          </li>
          <li class="twitter-w3">
            <a href="#twitter">
              <span class="fa fa-twitter"></span>
            </a>
          </li>
          <li class="google-w3">
            <a href="#google">
              <span class="fa fa-google-plus"></span>
            </a>
          </li>
          <li class="dribble-w3">
            <a href="#dribble">
              <span class="fa fa-dribbble"></span>
            </a>
          </li>
        </ul>
        <!-- //social icons -->
      </div>
      <div class="col-lg-4 col-sm-6 footer-grid_section_1its mt-lg-0 mt-5">
        <div class="footer-title">
          <h3>Contact Us</h3>
        </div>
        <div class="footer-text mt-4">
          <p><strong>Address :</strong> Shwe Taung Kyar street, Near the Embassy of Italy, Yangon, Myanmar
            YNG - 11211.</p>
          <p class="my-2"><strong>Phone :</strong> <a href="tel:+95 971 912 102">+95 971 912 102</a></p>
          <p><strong>Email :</strong> <a href="mailto: mnpastelería@email.com">mnpastelería@email.com</a></p>
        </div>
        <div class="footer-title mt-4 pt-md-2">
          <h3>Payments we accept</h3>
        </div>
        <ul class="list-unstyled payment-links mt-4">
          <li>
            <a href="#payment"><img src="assets/images/pay2.png" class="radius-image" width="55px" alt=""></a>
          </li>
          <li>
            <a href="#payment"><img src="assets/images/pay5.png" class="radius-image" width="55px" alt=""></a>
          </li>
          <li>
            <a href="#payment"><img src="assets/images/pay1.png" class="radius-image" width="55px" alt=""></a>
          </li>
          <li>
            <a href="#payment"><img src="assets/images/pay4.png" class="radius-image" width="55px" alt=""></a>
          </li>
        </ul>
      </div>
      <div class="col-lg-4 col-sm-6 footer-grid_section_1its footer-text mt-lg-0 mt-5">
        <div class="footer-title">
          <h3>Login to order</h3>
        </div>
        <div class="info-form-right mt-4 p-0">
          <p class="mb-4">Enter your username and password the latest news, updates and special offers from us.</p>
          <form action="login_process.php" method="POST" enctype="multipart/form-data">
            <div class="form-group mb-2">
              
            <div>
                <!-- <label for="usern">Username:</label> -->
			    <input type="text" class="form-control" name="usern" id="usern" placeholder="Username" required>

		    </div>
		    <br>

            <div>
              <!-- <label for="passw">Password:</label> -->
			    <input type="password" class="form-control" name="passw" id='passw'placeholder="Password" required>

		    </div>
		    
              <!-- <input type="email" class="form-control" name="Email" placeholder="Email" required=""> -->
<br>
              <!-- <input type="password" class="form-control" name="Password" placeholder="Password" required=""> -->

            </div>
            <button type="submit" class="btn btn-style btn-primary w-100 d-block ml-auto py-2" value= 'Entry'>Login</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- //footer -->
<!-- copyright -->
<div class="cpy-right text-center py-4">
  <p>© 2020 Midnight Pastelería. All rights reserved </p>
</div>
<!-- //copyright -->

 <!-- move top -->
 <button onclick="topFunction()" id="movetop" title="Go to top">
  <span class="fa fa-level-up" aria-hidden="true"></span>
</button>
<script>
  // When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function () {
    scrollFunction()
  };

  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      document.getElementById("movetop").style.display = "block";
    } else {
      document.getElementById("movetop").style.display = "none";
    }
  }

  // When the user clicks on the button, scroll to the top of the document
  function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
</script>
<!-- /move top -->

<script src="assets/js/jquery-3.3.1.min.js"></script> <!-- Common jquery plugin -->

<script src="assets/js/theme-change.js"></script><!-- theme switch js (light and dark)-->

<script src="assets/js/owl.carousel.js"></script><!-- owl carousel -->

<!-- script for tesimonials carousel slider -->
<script>
  $(document).ready(function () {
    $("#owl-demo1").owlCarousel({
      loop: true,
      margin: 20,
      nav: false,
      responsiveClass: true,
      responsive: {
        0: {
          items: 1,
          nav: false
        },
        1000: {
          items: 1,
          nav: false,
          loop: false
        }
      }
    })
  })
</script>
<!-- //script for tesimonials carousel slider -->

<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script>
  $(document).ready(function () {
    $('.popup-with-zoom-anim').magnificPopup({
      type: 'inline',

      fixedContentPos: false,
      fixedBgPos: true,

      overflowY: 'auto',

      closeBtnInside: true,
      preloader: false,

      midClick: true,
      removalDelay: 300,
      mainClass: 'my-mfp-zoom-in'
    });

    $('.popup-with-move-anim').magnificPopup({
      type: 'inline',

      fixedContentPos: false,
      fixedBgPos: true,

      overflowY: 'auto',

      closeBtnInside: true,
      preloader: false,

      midClick: true,
      removalDelay: 300,
      mainClass: 'my-mfp-slide-bottom'
    });
  });
</script>

<script src="assets/js/counter.js"></script>

<!-- gallery popup js -->
<script src="assets/js/smartphoto.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    const sm = new SmartPhoto(".js-img-viwer", {
      showAnimation: false
    });
    // sm.destroy();
  });
</script>
<!-- //gallery popup js -->

<!--/MENU-JS-->
<script>
  $(window).on("scroll", function () {
    var scroll = $(window).scrollTop();

    if (scroll >= 80) {
      $("#site-header").addClass("nav-fixed");
    } else {
      $("#site-header").removeClass("nav-fixed");
    }
  });

  //Main navigation Active Class Add Remove
  $(".navbar-toggler").on("click", function () {
    $("header").toggleClass("active");
  });
  $(document).on("ready", function () {
    if ($(window).width() > 991) {
      $("header").removeClass("active");
    }
    $(window).on("resize", function () {
      if ($(window).width() > 991) {
        $("header").removeClass("active");
      }
    });
  });
</script>
<!--//MENU-JS-->

<!-- disable body scroll which navbar is in active -->
<script>
  $(function () {
    $('.navbar-toggler').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- //disable body scroll which navbar is in active -->

<!--bootstrap-->
<script src="assets/js/bootstrap.min.js"></script>
<!-- //bootstrap-->

</body>

</html>