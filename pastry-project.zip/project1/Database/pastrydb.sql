-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2024 at 11:02 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pastrydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_Id` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_Id`, `Username`, `Password`) VALUES
(1, 'admin', 'admin'),
(2, 'Admin111', 'admin'),
(3, 'admin002', 'admin'),
(4, 'admin01', 'admin'),
(5, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Category_Id` int(11) NOT NULL,
  `Category_Name` varchar(200) NOT NULL,
  `Type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Category_Id`, `Category_Name`, `Type`) VALUES
(1, 'Pastries', 'Wheat base'),
(2, 'Appetizers', 'Snack'),
(3, 'Cake', 'Dessert'),
(4, 'Cold', 'Drinks'),
(5, 'Hot', 'Drink'),
(6, 'Wine', 'Alcohol'),
(7, 'Seasonal Offer', 'All Type');

-- --------------------------------------------------------

--
-- Table structure for table `checkdetail`
--

CREATE TABLE `checkdetail` (
  `Check_out_Id` varchar(50) NOT NULL,
  `Item_Id` int(11) NOT NULL,
  `Price` decimal(10,0) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checkdetail`
--

INSERT INTO `checkdetail` (`Check_out_Id`, `Item_Id`, `Price`, `Quantity`) VALUES
('0', 1, 0, 1),
('0', 2, 0, 2),
('0', 4, 0, 2),
('0', 5, 0, 1),
('0', 6, 0, 1),
('CH-001', 1, 7, 1),
('CH-001', 3, 5, 1),
('CH-001', 5, 20, 1),
('CH-001', 6, 15, 2),
('CH-001', 8, 18, 1),
('CH-002', 1, 7, 3),
('CH-002', 2, 5, 1),
('CH-003', 1, 7, 1),
('CH-003', 4, 15, 3),
('CH-004', 1, 7, 3),
('CH-004', 4, 15, 3),
('CH-005', 1, 7, 1),
('CH-005', 5, 20, 2),
('CH-005', 6, 15, 2),
('CH-006', 2, 5, 1),
('CH-007', 1, 7, 3);

-- --------------------------------------------------------

--
-- Table structure for table `check_out`
--

CREATE TABLE `check_out` (
  `Check_out_Id` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Cus_Id` int(11) DEFAULT NULL,
  `Total_Quantity` int(11) NOT NULL,
  `VAT` decimal(10,0) NOT NULL,
  `Total_Amount` decimal(10,0) NOT NULL,
  `Grand_Total` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `check_out`
--

INSERT INTO `check_out` (`Check_out_Id`, `Cus_Id`, `Total_Quantity`, `VAT`, `Total_Amount`, `Grand_Total`) VALUES
('CH-001', 4, 3, 1, 21, 22),
('CH-002', 4, 3, 1, 21, 22),
('CH-003', 4, 6, 3, 66, 69),
('CH-004', 4, 6, 3, 66, 69),
('CH-005', 5, 5, 4, 77, 81),
('CH-006', 4, 1, 0, 5, 5),
('CH-007', 4, 3, 1, 21, 22);

-- --------------------------------------------------------

--
-- Table structure for table `cus`
--

CREATE TABLE `cus` (
  `Cus_Id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cus`
--

INSERT INTO `cus` (`Cus_Id`, `Name`, `Email`, `Username`, `Password`) VALUES
(1, 'Omm', 'omm@gmail.com', 'omm111', 'onnnn'),
(2, 'Mill', 'milll22@gmail.com', 'mill332', 'qazxsw'),
(3, 'Jass', 'jassy@gmail.com', 'jas123', '123456'),
(4, 'Swai', 'maswaithi@gmail.com', 'swaithi777', '1234'),
(5, 'Perri', 'perrihan123@gmail.com', 'perri123', '12345'),
(6, 'Su Su', 'susu12@gmail.com', 'suw4323', '');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `Item_Id` int(11) NOT NULL,
  `Category_Name` varchar(500) NOT NULL,
  `Item_Name` varchar(500) NOT NULL,
  `Price` decimal(10,0) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Category_Id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`Item_Id`, `Category_Name`, `Item_Name`, `Price`, `Description`, `Category_Id`) VALUES
(1, 'Pastries', 'Cannoli', 7, 'Ricotta Chocolate ,Ricotta Custard ,Pistachio', 1),
(2, 'Pastries', 'Puff', 5, 'Chicken, Curry, Berries', 1),
(3, 'Hot', 'Milk', 5, 'Creamy Milk', 5),
(4, 'Cake', 'Fruit Cake', 15, 'Mixed Fruit', 3),
(5, 'Appetizers', 'Sweet Pea Pesto', 20, 'Vegan only with Pea', 2),
(6, 'Cold', 'Ice-Americano', 15, '90% coffee only ', 4),
(7, 'Wine', 'Albertoni', 20, 'Per Glass serve', 6),
(8, 'Seasonal Offer', 'Cannoli And Ice-American', 18, '15% OFF HOT DEALS', 7);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `Review_Id` int(11) NOT NULL,
  `Cus_Id` int(11) DEFAULT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`Review_Id`, `Cus_Id`, `Name`, `Email`, `Message`) VALUES
(1, 4, 'Swai', 'maswaithi@gmail.com', 'Highly recommended'),
(2, 4, 'Swai', 'maswaithi@gmail.com', 'Nice experiences');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_Id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Category_Id`);

--
-- Indexes for table `checkdetail`
--
ALTER TABLE `checkdetail`
  ADD PRIMARY KEY (`Check_out_Id`,`Item_Id`);

--
-- Indexes for table `check_out`
--
ALTER TABLE `check_out`
  ADD PRIMARY KEY (`Check_out_Id`),
  ADD KEY `Cus_Id` (`Cus_Id`);

--
-- Indexes for table `cus`
--
ALTER TABLE `cus`
  ADD PRIMARY KEY (`Cus_Id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`Item_Id`),
  ADD KEY `Category_Id` (`Category_Id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`Review_Id`),
  ADD KEY `Cus_Id` (`Cus_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Category_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cus`
--
ALTER TABLE `cus`
  MODIFY `Cus_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `Item_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `Review_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `check_out`
--
ALTER TABLE `check_out`
  ADD CONSTRAINT `check_out_ibfk_1` FOREIGN KEY (`Cus_Id`) REFERENCES `cus` (`Cus_Id`);

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`Category_Id`) REFERENCES `category` (`Category_Id`);

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`Cus_Id`) REFERENCES `cus` (`Cus_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
