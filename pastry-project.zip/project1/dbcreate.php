<?php
	$host = "localhost";
	$username="root";
	$password="";

	$connection=mysqli_connect($host,$username,$password);

	$sql="create database pastrydb";

	if(mysqli_query($connection,$sql))
		echo "Pastry database is created!";

	else echo "Error is found";
	



?>