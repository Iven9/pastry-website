<?php
	$host = "localhost";
	$username="root";
	$password="";
    $dbname="pastrydb";


	$connection=mysqli_connect($host,$username,$password,$dbname);

	
	



?>