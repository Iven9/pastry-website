<!-- <?php
session_start();

// Your database connection and other necessary includes
include("connection.php");

$usern = trim($_POST['usern']);
$passw = trim($_POST['passw']);

// Assuming you have checked the username and password and retrieved the user role from the database
// ...

if ($passw == 'admin') {
    // Redirect admin to menu.php
    $_SESSION['passw'] = "admin";
    $_SESSION['role'] = "admin"; // You should retrieve the actual role from your database
    header("Location: menu.php");
    exit();
} else {
    // Check customer credentials
    $sql = "SELECT Cus_Id FROM cus WHERE Username= ? AND Password=?";
    $stmt = mysqli_prepare($connection, $sql);
    mysqli_stmt_bind_param($stmt, 'ss', $usern, $passw);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    $num_rows = mysqli_stmt_num_rows($stmt);

    if ($num_rows == 0) {
        echo "<script>alert('Username and Password Do Not Match! Try Again'); window.location ='login.php'</script>";
    } else {
        // Valid customer login
        mysqli_stmt_bind_result($stmt, $Cus_Id);
        mysqli_stmt_fetch($stmt);
        $_SESSION['passw'] = $passw;
        $_SESSION['role'] = "customer"; // You should retrieve the actual role from your database
        $_SESSION['Cus_Id'] = $Cus_Id;
        header("Location: index.php");
        exit();
    }

    mysqli_stmt_close($stmt);
}
  //  include("connection.php");
  // //  if(isset($_SESSION['counter']))
	// // 	{
	// // 		if($_SESSION['counter']==3)
	// // 		{
	// // 			setcookie("failure","1",time()+60); //60 sec
	// // 			echo "<script>window.location='timer.php'</script>";
						
	// // 		}
				
	// // 	}
	// // 	else {
	// // 		$_SESSION['counter']=1;
	// // 	} 
   

  //       $usern = trim($_POST['usern']);
	//   	$passw = trim($_POST['passw']);

  //     // $usern1 = trim($_POST['usern1']);
	//   	// $passw1 = trim($_POST['passw1']);
  //   // echo '<br>Username: '.$usern."<hr>";
  //   $_SESSION['passw'] = "admin";
  //   if ($passw =='admin') 
	// 	{
      
  //     echo"<script> window.location ='menu.php';</script>";

		
  //     if ($num_rows == 0) {
  //       echo "<script>alert('Username and Password Do Not Match! Try Again'); window.location ='login.php'</script>";
  //     } else {
  //       // Valid login, set session variables including role
  //       $_SESSION['passw'] = "admin";
  //       $_SESSION['role'] = "admin"; // You should retrieve the actual role from your database
  //       header("Location: menu.php");
  //       exit();
  //     }
  //   }
  //   else{
  //     $sql = "select * from cus where Username='$usern' and Password='$passw'";

  //      $result=mysqli_query($connection,$sql);

	//     $num_rows=mysqli_num_rows($result);

	// // echo "<script>window.location='Show_all.php'</script>";

    
  //     if($num_rows=="0") 
  //        {
  //      // $_SESSION['counter']++;  			
       
  //      echo "<script> alert('Username and Password Does Not Match!  Try Again'); 
  //      window.location ='login.php'</script>";  	

  //          }		

  //         else {
  //       // echo "Valid Customer!";
  //          echo "<script>window.location ='index.php'</script>";

  //            }
  //           }      

	// echo "<script>window.location='Show_all.php'</script>";
   
    // else {
    //     echo "Valid Customer!";

    //     // $_SESSION['usern'] = $usern;


        
    
?>

</body>
</html>