
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>review Process</title>
</head>
<body>
	<?php
	
	include("connection.php");

	 
	$w3lName = trim($_POST["w3lName"]);

		$w3lSender = trim($_POST["w3lSender"]);
		
		$w3lMessage = trim($_POST["w3lMessage"]);

		$id_query = "SELECT Cus_ID FROM cus WHERE Name = '$w3lName'";
        $result = mysqli_query($connection, $id_query);
        
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $cus_id = $row['Cus_ID'];
        
        
		$w3lName= mysqli_real_escape_string($connection,$w3lName);
		
		$w3lSender= mysqli_real_escape_string($connection,$w3lSender);

		$w3lMessage= mysqli_real_escape_string($connection,$w3lMessage);
      


		
		
			// $sql_existing_name ="select * from camp where pname='$pname'";
			
			// $result = mysqli_query($connection,$sql_existing_name);
			
			// $num_rows=mysqli_num_rows($result);

			// if($num_rows==0){

			

				$sql="insert into review (Cus_Id , Name, Email , Message ) values( '$cus_id' ,'$w3lName' ,  '$w3lSender' ,'$w3lMessage')";

				if(mysqli_query($connection,$sql))
					echo "Review Successful! <script>alert ('Thank you for your feedback'); window.location ='index.php';</script>";

				else echo "Error is found";
			

			 }

			// else
			// {
			//   echo "Existed Pitch! Please Login with other username again <br>"; 
			// }
			
		

	?>

</body>
</html>