<?php 
	session_start();
	$host = "localhost";
	$username="root";
	$password="";
    $dbname="pastrydb";


	$connection=mysqli_connect($host,$username,$password,$dbname);

	$passw= $_SESSION['passw'];

	if(  $passw=="admin"){


	// $passw = ''; // Initialize $passw outside the if block

	// if(isset($_SESSION['usern'])) {
    //     $passw= $_SESSION['passw'];

    //     if( $passw=='admin'){
            $id= $_GET['Item_Id'];

            $sql ="delete from items where Item_Id=$id "; //value

            if(mysqli_query($connection,$sql)) 
				echo "Deleted iteam Successful! <script> window.location ='menu.php';</script>";

            else {
                echo "Error is found <br>";
            }
		}

    //     } else {
    //         // echo "Access Denied !";
    //     }
    // } else {
    //     // echo "Access Denied !";
    // }
?>
