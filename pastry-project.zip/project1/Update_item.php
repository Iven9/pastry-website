<?php
include("connection.php");
if (isset($_POST['Item_Id'])) {
     $id = $_POST['Item_Id'];
 
     $Item_Name = $_POST['Item_Name'];
     $Price = $_POST['Price'];
     $Description = $_POST['Description'];
 
     $sql = "UPDATE items SET Item_Name='$Item_Name',Price='$Price', Description='$Description' WHERE Item_Id = '$id'";
 
     $result = mysqli_query($connection, $sql);
 
     if ($result) {
         echo "Successfully Updated!<br>"; echo "<script>window.location ='menu.php'</script>";
 
     } else {
         echo "Error: " . mysqli_error($connection) . "<br>";
     }
 } else {
     echo "Error: 'Item_Name' not set in the POST array.<br>";
 }
 
 mysqli_close($connection);
 

// $id = $_POST['Offer_Id'];
        
//  $Offer_iteams =$_POST['Offer_iteams'];
//  $Orignal_Price = $_POST['Orignal_Price'];

//  $Price=$_POST['Price'];
//  $Description=$_POST['Description'];
 
//  $sql ="update offer set Offer_iteams='$Offer_iteams',Orignal_Price='$Orignal_Price', Price='$Price', Description='$Description'  where Offer_Id= '$id' "; //value

// // if(mysqli_query($connection,$sql))  echo "Successfully Updated!<br>";
// // else echo "Error is found <br>";
// $result = mysqli_query($connection, $sql);


// if ($result) {
//      echo "Successfully Updated!<br>";
//  } else {
//      echo "Error: " . mysqli_error($connection) . "<br>";
//  }
 
//  mysqli_close($connection);


 
// if(isset($_POST['id']))
// {
//  $id = $_POST['id'];
        
//  $Offer_iteams =$_POST['Offer_iteams'];
//  $Orignal_Price = $_POST['Orignal_Price'];

//  $Price=$_POST['Price'];
//  $Description=$_POST['Description'];
 
//  $sql ="update offer set Offer_iteams='$Offer_iteams',Orignal_Price='$Orignal_Price', Price='$Price', Description='$Description'  where id=$id "; //value

// if(mysqli_query($connection,$sql)) 
//      echo "Successfully Updated!<br>";
// else echo "Error is found <br>";
// }
 ?>

